//
//  main.m
//  MonoBotLSS
//
//  Created by Wojtek Szumski on 02/03/2019.
//  Copyright © 2019 Monoli. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppleScriptObjC/AppleScriptObjC.h>

int main(int argc, const char * argv[]) {
    [[NSBundle mainBundle] loadAppleScriptObjectiveCScripts];
    return NSApplicationMain(argc, argv);
}
